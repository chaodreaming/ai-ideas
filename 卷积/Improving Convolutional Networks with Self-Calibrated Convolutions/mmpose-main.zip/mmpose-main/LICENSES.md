# Licenses for special algorithms

In this file, we list the algorithms with other licenses instead of Apache 2.0. Users should be careful about adopting these algorithms in any commercial matters.

| Algorithm |                                                                            Files                                                                            |     License      |
| :-------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------: | :--------------: |
|  EDPose   | [mmpose/models/heads/transformer_heads/edpose_head.py](https://github.com/open-mmlab/mmpose/blob/main/mmpose/models/heads/transformer_heads/edpose_head.py) | IDEA License 1.0 |
