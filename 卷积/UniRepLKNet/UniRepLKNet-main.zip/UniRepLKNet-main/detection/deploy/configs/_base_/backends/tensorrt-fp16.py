backend_config = dict(
    type='tensorrt', common_config=dict(fp16_mode=True, max_workspace_size=0))
