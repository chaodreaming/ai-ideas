# Copyright (c) Shanghai AI Lab. All rights reserved.
from .mask_pseudo_sampler import MaskPseudoSampler  # noqa: F401,F403
