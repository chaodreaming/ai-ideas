# ScConv
This is the unofficial implementation of [SCConv: Spatial and Channel Reconstruction Convolution for Feature Redundancy ](https://openaccess.thecvf.com/content/CVPR2023/papers/Li_SCConv_Spatial_and_Channel_Reconstruction_Convolution_for_Feature_Redundancy_CVPR_2023_paper.pdf).

Update: Solved some bugs in SRU, thanks to @[huihui43](https://github.com/huihui43) , [zhangzh16](https://github.com/zhangzh16).
## Actually, you just need to insert the ScConv into your model anywhere.
Welcome to submit your issues.
