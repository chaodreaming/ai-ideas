# GENERATED VERSION FILE
# TIME: Thu Nov 10 10:11:46 2022
__version__ = '1.2.0+10018c6'
short_version = '1.2.0'
version_info = (1, 2, 0)
