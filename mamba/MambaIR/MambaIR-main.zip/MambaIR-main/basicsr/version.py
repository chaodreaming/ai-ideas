# GENERATED VERSION FILE
# TIME: Mon Nov 21 05:26:10 2022
__version__ = '1.3.5'
__gitsha__ = 'unknown'
version_info = (1, 3, 5)
