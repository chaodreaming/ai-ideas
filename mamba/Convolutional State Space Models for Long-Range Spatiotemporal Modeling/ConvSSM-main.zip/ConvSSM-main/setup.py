from distutils.core import setup
from setuptools import find_packages

setup(
    name='convssm',
    version='0.0.1',
    packages=find_packages()
)