from .train_api import train_segmentor

__all__ = ['train_segmentor']
