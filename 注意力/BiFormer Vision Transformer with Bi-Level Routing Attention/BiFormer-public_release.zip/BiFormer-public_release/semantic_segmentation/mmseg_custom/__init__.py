
from .align_resize import AlignResize

__all__=['AlignResize']