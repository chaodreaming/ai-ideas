# Copyright (c) OpenMMLab. All rights reserved.
from .gmm import GaussianMixture

__all__ = ['GaussianMixture']
