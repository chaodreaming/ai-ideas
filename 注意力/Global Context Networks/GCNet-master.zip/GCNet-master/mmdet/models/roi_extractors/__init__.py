from .single_level import SingleRoIExtractor

__all__ = ['SingleRoIExtractor']
