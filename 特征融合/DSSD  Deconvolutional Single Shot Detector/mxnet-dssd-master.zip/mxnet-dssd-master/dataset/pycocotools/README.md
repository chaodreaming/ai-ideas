This is a modified version of https://github.com/pdollar/coco python API.
No `make` is required, but this will not support mask functions.
