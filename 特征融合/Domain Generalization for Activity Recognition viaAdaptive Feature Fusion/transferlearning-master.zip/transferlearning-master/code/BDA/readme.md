# Balanced Distribution Adaptation

Since the transfer learning repo was reorganized, please visit https://github.com/jindongwang/transferlearning/tree/master/code/traditional/BDA for the BDA code.