# MEDA: Manifold Embedded Distribution Alignment

This is the official Matlab code for MEDA.

## Usage

After download the data from [here](https://github.com/jindongwang/transferlearning/tree/master/code/traditional/MEDA#office-31-dataset), you can run `demo_office_caltech_surf.m`.

More results can be found in [here](https://github.com/jindongwang/transferlearning/tree/master/code/traditional/MEDA)