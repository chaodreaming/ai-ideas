mv download_pack/cv_data CV_adv/data
mv download_pack/cv_adv_models/* CV_adv/results/
mv download_pack/cv_backdoor_models/* CV_backdoor/results/
