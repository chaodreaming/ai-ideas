<<<<<<< HEAD
# B-JMMD
Balanced joint maximum mean discrepancy for deep transfer learning
=======

This is the transfer learning library for the following paper:

### Balanced Joint Maximum Mean Discrepancy for Deep Transfer Learning 

## Citation
If you use this code for your research, please consider citing:
```
    @article{Chuangji2020Balanced,
        title={Balanced Joint Maximum Mean Discrepancy for Deep Transfer Learning},
        author={Chuangji Meng and Cunlu Xu and Qin Lei and Wei Su and Jinzhao Wu},
        journal={Analysis and Applications},
        number={2},
        year={2020},
    }
        
```

## Contact
If you have any problem about our code, feel free to contact 
- mengchj16@lzu.edu.cn
- clxu@lzu.edu.cn
- leiqin@mail.lzjtu.cn

or describe your problem in Issues.
>>>>>>> 7b5bf33... first commit
