Download the Office-31 dataset (raw images) and extract it into this directory.
This directory should look like:
data
--OFFICE31
----amazon
------class1
------class2
...
----webcam
------(same as amazon)
----dslr
------(same as amazon)