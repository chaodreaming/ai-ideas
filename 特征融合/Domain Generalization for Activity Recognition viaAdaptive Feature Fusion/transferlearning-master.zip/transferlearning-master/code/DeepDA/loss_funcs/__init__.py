from loss_funcs.mmd import *
from loss_funcs.coral import *
from loss_funcs.adv import *
from loss_funcs.lmmd import *
from loss_funcs.daan import *
from loss_funcs.bnm import *