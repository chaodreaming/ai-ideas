# Domain adversarial neural network (DANN/RevGrad)

This is a Pytorch implementation of Unsupervised domain adaptation by backpropagation (also know as *DANN* or *RevGrad*).


**Reference**

Ganin Y, Lempitsky V. Unsupervised domain adaptation by backpropagation. ICML 2015.
