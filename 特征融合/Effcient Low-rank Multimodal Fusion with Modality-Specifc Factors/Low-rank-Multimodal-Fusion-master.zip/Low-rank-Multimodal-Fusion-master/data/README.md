### Datasets
The following link contains the processed data of CMU-MOSI, IEMOCAP, and POM:

https://drive.google.com/open?id=1CixSaw3dpHESNG0CaCJV6KutdlANP_cr