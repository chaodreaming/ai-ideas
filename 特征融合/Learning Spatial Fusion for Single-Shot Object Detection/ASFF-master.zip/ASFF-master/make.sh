cd utils/DCN

python setup.py install
