
# Download COCO test-dev2017

import torch

torch.hub.download_url_to_file('https://ultralytics.com/assets/coco2017labels.zip', 'tmp.zip')

