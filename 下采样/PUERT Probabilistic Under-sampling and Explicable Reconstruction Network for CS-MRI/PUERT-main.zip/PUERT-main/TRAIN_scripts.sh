# train PUERT. choose the ratio, 1D or 2D
python train_PUERT.py  --cs_ratio 10 --flag_1D 0
python train_PUERT.py  --cs_ratio 10 --flag_1D 1

# train PUERTPlus
python train_PUERTPlus.py  --cs_ratio 10 --flag_1D 0