# test PUERT
## use our provided best model to test ratio 10 version 2D
python test_PUERT.py  --cs_ratio 10 --flag_1D 0 --model_best 1
## use our provided best model to test ratio 10 version 1D
python test_PUERT.py  --cs_ratio 10 --flag_1D 1 --model_best 1

# test PUERTPlus
## use our provided best model to test ratio 10 version 2D
python test_PUERTPlus.py  --cs_ratio 10 --flag_1D 0 --model_best 1