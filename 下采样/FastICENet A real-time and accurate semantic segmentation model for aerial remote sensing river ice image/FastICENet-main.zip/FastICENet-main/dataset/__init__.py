from .camvid import *
from .cityscapes import *
from .river import *